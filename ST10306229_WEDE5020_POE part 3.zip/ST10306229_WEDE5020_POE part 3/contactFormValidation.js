// Selecting form and critical fields
const contactForm = document.getElementById('contactForm');
const nameField = document.getElementById('name');
const emailField = document.getElementById('email');
const messageField = document.getElementById('message');

// Clear initial values when fields are clicked
nameField.addEventListener('focus', () => {
    if (nameField.value === 'Your Name') {
        nameField.value = '';
    }
});

emailField.addEventListener('focus', () => {
    if (emailField.value === 'Your Email') {
        emailField.value = '';
    }
});

messageField.addEventListener('focus', () => {
    if (messageField.value === 'Your Message') {
        messageField.value = '';
    }
});

// Form submission validation
contactForm.addEventListener('submit', function(event) {
    if (nameField.value === '' || nameField.value === 'Your Name' ||
        emailField.value === '' || emailField.value === 'Your Email' ||
        messageField.value === '' || messageField.value === 'Your Message') {
        alert('Please fill in the required fields (Name, Email, Message) before submitting the form.');
        event.preventDefault();
    } else {
        // Our actual email address
        const emailLink = `mailto:info@smarthomesolutions.com?subject=${encodeURIComponent(subject.value)}&body=${encodeURIComponent(message.value)}`;
        window.location.href = emailLink;
    }
});
