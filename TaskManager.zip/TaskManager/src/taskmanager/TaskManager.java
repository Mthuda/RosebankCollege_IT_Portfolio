/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package taskmanager;
import javax.swing.JOptionPane;
/**
 *
 * @author lab_services_student
 */
public class TaskManager {
     private boolean loggedIn;
    private String username;
    private String password;
    private Task[] tasks;
    private int taskCount;
    private int totalHours;

    public TaskManager() {
        loggedIn = false;
        username = "";
        password = "";
        tasks = null;
        taskCount = 0;
        totalHours = 0;
    }

    // Method to register a new user
    public void registerUser() {
        String firstName = JOptionPane.showInputDialog(null, "Enter your first name:");
        String lastName = JOptionPane.showInputDialog(null, "Enter your last name:");
        String username = JOptionPane.showInputDialog(null, "Enter your username:");

        if (!checkUserName(username)) {
            JOptionPane.showMessageDialog(null, "Username is not correctly formatted, please ensure that your username contains an underscore and is no more than 5 characters in length.");
            registerUser(); // Re-prompt for registration
            return;
        }

        String password = JOptionPane.showInputDialog(null, "Enter your password:");

        if (!checkPasswordComplexity(password)) {
            JOptionPane.showMessageDialog(null, "Password is not correctly formatted, please ensure that the password contains at least 8 characters, a capital letter, a number, and a special character.");
            registerUser(); // Re-prompt for registration
            return;
        }

        this.username = username;
        this.password = password;
        loggedIn = false;
        JOptionPane.showMessageDialog(null, "Registration successful. Please log in to continue.");
    }

    // Method to check if the username is correctly formatted
    private boolean checkUserName(String username) {
        if (username.length() > 5 || !username.contains("_")) {
            return false;
        }
        return true;
    }

    // Method to check if the password meets the complexity requirements
    private boolean checkPasswordComplexity(String password) {
        String regex = "^(?=.*[a-z])(?=.*[A-Z])(?=.*\\d)(?=.*[@$!%*?&])[A-Za-z\\d@$!%*?&]{8,}$";
        return password.matches(regex);
    }

    // Method to log in an existing user
    public void loginUser() {
        String username = JOptionPane.showInputDialog(null, "Enter your username:");
        String password = JOptionPane.showInputDialog(null, "Enter your password:");

        if (username.equals(this.username) && password.equals(this.password)) {
            loggedIn = true;
            JOptionPane.showMessageDialog(null, "Login successful. Welcome to EasyKanban.");
        } else {
            loggedIn = false;
            JOptionPane.showMessageDialog(null, "Invalid username or password. Please try again.");
            loginUser(); // Re-prompt for login
        }
    }

    // Method to display the menu
    public void showMenu() {
        Object[] options = { "Add a task", "Mark a task as done", "Search for a task by name",
                "Search for tasks by developer", "Delete a task", "Display full task report", "Logout" };

        int choice = JOptionPane.showOptionDialog(null, "=== Main Menu ===", "EasyKanban", JOptionPane.DEFAULT_OPTION,
                JOptionPane.PLAIN_MESSAGE, null, options, options[0]);

        switch (choice) {
            case 0:
                addTask();
                break;
            case 1:
                markTaskAsDone();
                break;
            case 2:
                searchTaskByName();
                break;
            case 3:
                searchTasksByDeveloper();
                break;
            case 4:
                deleteTask();
                break;
            case 5:
                displayFullTaskReport();
                break;
            case 6:
                logout();
                break;
            default:
                JOptionPane.showMessageDialog(null, "Invalid choice.");
        }
    }

    // Method to add a task
    private void addTask() {
        int numTasks = Integer.parseInt(JOptionPane.showInputDialog(null, "Enter the number of tasks you wish to enter:"));
        tasks = new Task[numTasks];

        for (int i = 0; i < numTasks; i++) {
            String taskName = JOptionPane.showInputDialog(null, "Enter the name of task " + i + ":");
            String taskDescription = JOptionPane.showInputDialog(null, "Enter the description of task " + i + ":");

            if (!checkTaskDescription(taskDescription)) {
                JOptionPane.showMessageDialog(null, "Please enter a task description of less than 50 characters.");
                i--; // Re-prompt for the same task
                continue;
            }

            String developerFirstName = JOptionPane.showInputDialog(null,
                    "Enter the first name of the developer assigned to task " + i + ":");
            String developerLastName = JOptionPane.showInputDialog(null,
                    "Enter the last name of the developer assigned to task " + i + ":");
            String taskDurationString = JOptionPane.showInputDialog(null,
                    "Enter the estimated duration of task " + i + " in hours:");
            int taskDuration = Integer.parseInt(taskDurationString);

            String taskID = createTaskID(taskName, i, developerLastName);

            String[] taskStatusOptions = { "To Do", "Done", "Doing" };
            int taskStatusChoice = JOptionPane.showOptionDialog(null, "Select the status of task " + i + ":",
                    "Task Status", JOptionPane.DEFAULT_OPTION, JOptionPane.PLAIN_MESSAGE, null, taskStatusOptions,
                    taskStatusOptions[0]);

            String taskStatus = taskStatusOptions[taskStatusChoice];

            Task task = new Task(taskName, i, taskDescription, developerFirstName, developerLastName, taskDuration,
                    taskID, taskStatus);
            tasks[i] = task;

            totalHours += taskDuration;

            JOptionPane.showMessageDialog(null, "Task successfully captured.\n\n" + task.printTaskDetails());
        }
    }

    // Method to check if the task description is not more than 50 characters
    private boolean checkTaskDescription(String taskDescription) {
        if (taskDescription.length() > 50) {
            return false;
        }
        return true;
    }

    // Method to create and return the task ID
    private String createTaskID(String taskName, int taskNumber, String developerLastName) {
        String taskID = taskName.substring(0, 2).toUpperCase() + ":" + taskNumber + ":" + developerLastName.substring(0, 3).toUpperCase();
        return taskID;
    }

    // Method to mark a task as done
    private void markTaskAsDone() {
        String taskName = JOptionPane.showInputDialog(null, "Enter the name of the task to mark as done:");
        boolean taskFound = false;

        for (int i = 0; i < tasks.length; i++) {
            if (tasks[i].getTaskName().equals(taskName)) {
                tasks[i].setTaskStatus("Done");
                JOptionPane.showMessageDialog(null, "Task marked as done: " + taskName);
                taskFound = true;
                break;
            }
        }

        if (!taskFound) {
            JOptionPane.showMessageDialog(null, "Task not found: " + taskName);
        }
    }

    // Method to search for a task by name
    private void searchTaskByName() {
        String taskName = JOptionPane.showInputDialog(null, "Enter the name of the task to search:");

        boolean taskFound = false;

        for (Task task : tasks) {
            if (task.getTaskName().equals(taskName)) {
                JOptionPane.showMessageDialog(null, task.printTaskDetails());
                taskFound = true;
                break;
            }
        }

        if (!taskFound) {
            JOptionPane.showMessageDialog(null, "Task not found: " + taskName);
        }
    }

    // Method to search for tasks by developer
    private void searchTasksByDeveloper() {
        String developerLastName = JOptionPane.showInputDialog(null, "Enter the last name of the developer to search:");

        boolean tasksFound = false;

        for (Task task : tasks) {
            if (task.getDeveloperLastName().equals(developerLastName)) {
                JOptionPane.showMessageDialog(null, task.printTaskDetails());
                tasksFound = true;
            }
        }

        if (!tasksFound) {
            JOptionPane.showMessageDialog(null, "No tasks found for developer: " + developerLastName);
        }
    }

    // Method to delete a task
    private void deleteTask() {
        String taskName = JOptionPane.showInputDialog(null, "Enter the name of the task to delete:");

        boolean taskFound = false;

        for (int i = 0; i < tasks.length; i++) {
            if (tasks[i].getTaskName().equals(taskName)) {
                Task[] updatedTasks = new Task[tasks.length - 1];

                // Copy all tasks except the one to be deleted
                int index = 0;
                for (int j = 0; j < tasks.length; j++) {
                    if (j != i) {
                        updatedTasks[index++] = tasks[j];
                    }
                }

                tasks = updatedTasks;
                taskCount--;

                JOptionPane.showMessageDialog(null, "Task deleted: " + taskName);
                taskFound = true;
                break;
            }
        }

        if (!taskFound) {
            JOptionPane.showMessageDialog(null, "Task not found: " + taskName);
        }
    }

    // Method to display the full task report
    private void displayFullTaskReport() {
        StringBuilder report = new StringBuilder("=== Task Report ===\n");

        for (Task task : tasks) {
            report.append(task.printTaskDetails());
            report.append("\n\n");
        }

        report.append("Total Task Count: ").append(taskCount).append("\n");
        report.append("Total Task Duration: ").append(totalHours).append(" hours\n");

        JOptionPane.showMessageDialog(null, report.toString());
    }

    // Method to log out the user
    private void logout() {
        loggedIn = false;
        JOptionPane.showMessageDialog(null, "Logged out successfully.");
    }

    public static void main(String[] args) {
        TaskManager taskManager = new TaskManager();
        taskManager.registerUser();
        taskManager.loginUser();

        if (taskManager.isLoggedIn()) {
            taskManager.showMenu();
        }
    }

    // Getter for loggedIn status
    public boolean isLoggedIn() {
        return loggedIn;
    }
}

class Task {
    private String taskName;
    private int taskNumber;
    private String taskDescription;
    private String developerFirstName;
    private String developerLastName;
    private int taskDuration;
    private String taskID;
    private String taskStatus;

    public Task(String taskName, int taskNumber, String taskDescription, String developerFirstName,
            String developerLastName, int taskDuration, String taskID, String taskStatus) {
        this.taskName = taskName;
        this.taskNumber = taskNumber;
        this.taskDescription = taskDescription;
        this.developerFirstName = developerFirstName;
        this.developerLastName = developerLastName;
        this.taskDuration = taskDuration;
        this.taskID = taskID;
        this.taskStatus = taskStatus;
    }

    public String printTaskDetails() {
        return "Task Status: " + taskStatus + "\n" + "Task Name: " + taskName + "\n" + "Task Number: " + taskNumber + "\n"
                + "Task Description: " + taskDescription + "\n" + "Developer First Name: " + developerFirstName + "\n"
                + "Developer Last Name: " + developerLastName + "\n" + "Task Duration: " + taskDuration + " hours\n"
                + "Task ID: " + taskID;
    }

    public String getTaskName() {
        return taskName;
    }

    public void setTaskStatus(String taskStatus) {
        this.taskStatus = taskStatus;
    }

    public String getDeveloperLastName() {
        return developerLastName;
    }
}